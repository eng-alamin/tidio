<?php

use Illuminate\Support\Facades\Route;

// ---- Public marketing website ----
Route::get('/', fn () => view('site.home'))->name('home');
Route::get('/pricing', fn () => view('site.pricing'))->name('pricing');
Route::get('/login', fn () => view('site.login'))->name('login');
Route::get('/register', fn () => view('site.register'))->name('register');

// ---- Tenant app panel (workspace-scoped, needs auth + EnsureBelongsToWorkspace) ----
Route::middleware(['auth', 'workspace'])->prefix('app')->name('app.')->group(function () {
    Route::get('/dashboard', fn () => view('app.dashboard'))->name('dashboard');
    Route::get('/inbox', fn () => view('app.inbox'))->name('inbox');
    Route::get('/flows', fn () => view('app.flows'))->name('flows');
    Route::get('/settings', fn () => view('app.settings'))->name('settings');
});

// ---- Super-admin (platform staff only) ----
Route::middleware(['auth:super_admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', fn () => view('super-admin.dashboard'))->name('dashboard');
    Route::get('/tenants', fn () => view('super-admin.tenants'))->name('tenants');
    Route::get('/billing', fn () => view('super-admin.billing'))->name('billing');
});
