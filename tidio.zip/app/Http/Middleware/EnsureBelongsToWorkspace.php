<?php

namespace App\Http\Middleware;

use App\Models\Workspace;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureBelongsToWorkspace
{
    // Every API route below is nested under /workspaces/{workspace}/..., so
    // this runs once per request and rejects cross-tenant access before any
    // controller code runs — the core of the multi-tenancy boundary at the
    // HTTP layer (the DB layer's boundary is workspace_id itself).
    public function handle(Request $request, Closure $next): Response
    {
        $workspace = $request->route('workspace');

        if (! $workspace instanceof Workspace) {
            abort(404);
        }

        $belongs = $workspace->users()
            ->where('users.id', $request->user()->id)
            ->wherePivot('status', 'active')
            ->exists();

        abort_unless($belongs, 403, 'You are not a member of this workspace.');

        return $next($request);
    }
}
