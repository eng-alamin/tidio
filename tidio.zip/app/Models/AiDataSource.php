<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Enums\AiDataSourceStatus;
use App\Enums\AiDataSourceType;

class AiDataSource extends Model
{
    use HasFactory;

    protected $fillable = ['workspace_id', 'type', 'source', 'status', 'last_synced_at'];

    protected $casts = [
        'last_synced_at' => 'datetime',
        'type' => AiDataSourceType::class,
        'status' => AiDataSourceStatus::class,
    ];

    public function workspace(): BelongsTo
    {
        return $this->belongsTo(Workspace::class);
    }
}
