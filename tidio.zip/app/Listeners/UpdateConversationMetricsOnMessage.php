<?php

namespace App\Listeners;

use App\Enums\MessageSenderType;
use App\Models\ConversationMetric;
use App\Events\MessageSent;

class UpdateConversationMetricsOnMessage
{
    // Fills in first_response_at / first_response_seconds the moment the
    // FIRST operator (or bot) message lands on a conversation. Later
    // operator messages don't touch it again — "first response" means first.
    public function handle(MessageSent $event): void
    {
        $message = $event->message;

        if (! in_array($message->sender_type, [MessageSenderType::Operator, MessageSenderType::Bot], true)) {
            return;
        }

        $metric = ConversationMetric::firstOrCreate(['conversation_id' => $message->conversation_id]);

        if ($metric->first_response_at !== null) {
            return; // already recorded, this isn't the first response
        }

        $firstInbound = $message->conversation->messages()
            ->where('sender_type', MessageSenderType::Visitor->value)
            ->oldest()
            ->first();

        $metric->update([
            'first_response_at' => $message->created_at,
            'first_response_seconds' => $firstInbound
                ? $message->created_at->diffInSeconds($firstInbound->created_at)
                : null,
        ]);
    }
}
