<?php

namespace App\Livewire\App;

use App\Models\Sla;
use Livewire\Attributes\Validate;
use Livewire\Component;

class SettingsSla extends Component
{
    #[Validate('required|integer|min:1')]
    public int $first_response_minutes = 60;

    #[Validate('required|integer|min:1')]
    public int $resolution_minutes = 1440;

    #[Validate('required|string')]
    public string $applies_to = 'tickets';

    public function mount(): void
    {
        $sla = Sla::where('workspace_id', app('currentWorkspace')->id)->first();

        if ($sla) {
            $this->first_response_minutes = $sla->first_response_minutes ?? 60;
            $this->resolution_minutes = $sla->resolution_minutes ?? 1440;
            $this->applies_to = $sla->applies_to ?? 'tickets';
        }
    }

    public function save(): void
    {
        $this->validate();

        Sla::updateOrCreate(
            ['workspace_id' => app('currentWorkspace')->id],
            [
                'first_response_minutes' => $this->first_response_minutes,
                'resolution_minutes' => $this->resolution_minutes,
                'applies_to' => $this->applies_to,
            ]
        );

        $this->dispatch('toast', message: 'SLA policy saved.');
    }

    public function render()
    {
        return view('livewire.app.settings-sla')
            ->layout('layouts.app', ['title' => 'Settings']);
    }
}
