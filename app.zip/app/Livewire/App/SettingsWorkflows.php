<?php

namespace App\Livewire\App;

use App\Models\WorkflowRule;
use Illuminate\Support\Collection;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Validate;
use Livewire\Component;

class SettingsWorkflows extends Component
{
    public bool $showCreate = false;

    public ?int $editingId = null;

    #[Validate('required|string|max:100')]
    public string $name = '';

    #[Validate('required|string|max:255')]
    public string $condition = '';

    #[Validate('required|string|max:255')]
    public string $action = '';

    #[Computed]
    public function workflows(): Collection
    {
        return WorkflowRule::query()
            ->where('workspace_id', app('currentWorkspace')->id)
            ->latest()
            ->get();
    }

    public function startCreate(): void
    {
        $this->reset(['name', 'condition', 'action', 'editingId']);
        $this->showCreate = true;
    }

    public function edit(int $workflowId): void
    {
        $workflow = WorkflowRule::where('workspace_id', app('currentWorkspace')->id)->findOrFail($workflowId);

        $this->editingId = $workflow->id;
        $this->name = $workflow->name;
        $this->condition = $workflow->condition;
        $this->action = $workflow->action;
        $this->showCreate = true;
    }

    public function save(): void
    {
        $this->validate();

        if ($this->editingId) {
            $workflow = WorkflowRule::where('workspace_id', app('currentWorkspace')->id)->findOrFail($this->editingId);
            $workflow->update([
                'name' => $this->name,
                'condition' => $this->condition,
                'action' => $this->action,
            ]);
            $toast = "Workflow \"{$this->name}\" updated.";
        } else {
            WorkflowRule::create([
                'workspace_id' => app('currentWorkspace')->id,
                'created_by' => auth()->id(),
                'name' => $this->name,
                'condition' => $this->condition,
                'action' => $this->action,
                'is_active' => false,
            ]);
            $toast = "Workflow \"{$this->name}\" created.";
        }

        $this->reset(['name', 'condition', 'action', 'editingId', 'showCreate']);
        unset($this->workflows);

        $this->dispatch('toast', message: $toast);
    }

    public function cancel(): void
    {
        $this->reset(['name', 'condition', 'action', 'editingId', 'showCreate']);
    }

    public function toggleActive(int $workflowId): void
    {
        $workflow = WorkflowRule::where('workspace_id', app('currentWorkspace')->id)->findOrFail($workflowId);
        $workflow->is_active = ! $workflow->is_active;
        $workflow->save();

        unset($this->workflows);
    }

    public function delete(int $workflowId): void
    {
        WorkflowRule::where('workspace_id', app('currentWorkspace')->id)->where('id', $workflowId)->delete();
        unset($this->workflows);

        $this->dispatch('toast', message: 'Workflow deleted.');
    }

    public function render()
    {
        return view('livewire.app.settings-workflows')
            ->layout('layouts.app', ['title' => 'Settings']);
    }
}
