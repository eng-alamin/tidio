<?php

namespace App\Livewire\App;

use App\Enums\ConversationStatus;
use App\Enums\MessageSenderType;
use App\Models\Conversation;
use App\Models\Message;
use Illuminate\Support\Collection;
use Livewire\Attributes\Computed;
use Livewire\Component;

class Inbox extends Component
{
    /** Which folder in the left nav is active: unassigned | mine | solved. */
    public string $folder = 'unassigned';

    public ?int $selectedConversationId = null;

    public string $newMessage = '';

    public bool $isNote = false;

    public function mount(): void
    {
        $this->selectedConversationId = $this->conversations->first()?->id;
    }

    #[Computed]
    public function conversations(): Collection
    {
        $workspace = app('currentWorkspace');

        return Conversation::query()
            ->where('workspace_id', $workspace->id)
            ->where('type', 'chat')
            ->when($this->folder === 'unassigned', fn ($q) => $q
                ->whereNull('assigned_operator_id')
                ->whereNotIn('status', [ConversationStatus::Solved, ConversationStatus::Spam]))
            ->when($this->folder === 'mine', fn ($q) => $q
                ->where('assigned_operator_id', auth()->id())
                ->whereNotIn('status', [ConversationStatus::Solved, ConversationStatus::Spam]))
            ->when($this->folder === 'solved', fn ($q) => $q->where('status', ConversationStatus::Solved))
            ->with(['contact', 'messages' => fn ($q) => $q->latest()->limit(1)])
            ->orderByDesc('last_message_at')
            ->get();
    }

    #[Computed]
    public function selectedConversation(): ?Conversation
    {
        if (! $this->selectedConversationId) {
            return null;
        }

        return Conversation::query()
            ->where('workspace_id', app('currentWorkspace')->id)
            ->with(['contact', 'visitor', 'assignedOperator', 'messages' => fn ($q) => $q->oldest()])
            ->find($this->selectedConversationId);
    }

    public function setFolder(string $folder): void
    {
        $this->folder = $folder;
        $this->selectedConversationId = $this->conversations->first()?->id;
    }

    public function selectConversation(int $conversationId): void
    {
        $this->selectedConversationId = $conversationId;
        $this->newMessage = '';
        $this->isNote = false;
    }

    public function toggleNoteMode(): void
    {
        $this->isNote = ! $this->isNote;
    }

    public function sendMessage(): void
    {
        $conversation = $this->selectedConversation;

        if (! $conversation || trim($this->newMessage) === '') {
            return;
        }

        Message::create([
            'conversation_id' => $conversation->id,
            'sender_type' => MessageSenderType::Operator,
            'sender_id' => auth()->id(),
            'body' => trim($this->newMessage),
            'is_private_note' => $this->isNote,
        ]);

        $conversation->update(['last_message_at' => now()]);

        unset($this->selectedConversation, $this->conversations);

        $this->newMessage = '';
        $this->isNote = false;

        $this->dispatch('message-sent');
    }

    public function markSolved(): void
    {
        $this->selectedConversation?->update(['status' => ConversationStatus::Solved, 'closed_at' => now()]);
        unset($this->conversations);
    }

    public function render()
    {
        return view('livewire.app.inbox')
            ->layout('layouts.app', ['title' => 'Inbox']);
    }
}
