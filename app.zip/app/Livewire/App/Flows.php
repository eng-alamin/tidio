<?php

namespace App\Livewire\App;

use App\Enums\FlowStatus;
use App\Enums\FlowTriggerType;
use App\Models\Flow;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Flows extends Component
{
    public string $search = '';

    public bool $showCreate = false;

    #[Validate('required|string|min:2|max:100')]
    public string $newName = '';

    #[Validate('required|string')]
    public string $newTrigger = 'page_visit';

    #[Computed]
    public function flows(): Collection
    {
        return Flow::query()
            ->where('workspace_id', app('currentWorkspace')->id)
            ->when($this->search, fn ($q) => $q->where('name', 'like', '%'.$this->search.'%'))
            ->withCount(['runs as visitors_reached' => fn ($q) => $q->select(DB::raw('count(distinct visitor_id)'))])
            ->latest()
            ->get();
    }

    public function createFlow(): void
    {
        $this->validate();

        $flow = Flow::create([
            'workspace_id' => app('currentWorkspace')->id,
            'created_by' => auth()->id(),
            'name' => $this->newName,
            'trigger_type' => $this->newTrigger,
            'status' => FlowStatus::Draft,
        ]);

        $this->reset(['newName', 'showCreate']);
        $this->newTrigger = 'page_visit';
        unset($this->flows);

        $this->dispatch('toast', message: "Flow \"{$flow->name}\" created as a draft.");
    }

    public function cycleStatus(int $flowId): void
    {
        $flow = Flow::where('workspace_id', app('currentWorkspace')->id)->findOrFail($flowId);

        $flow->status = match ($flow->status) {
            FlowStatus::Draft => FlowStatus::Active,
            FlowStatus::Active => FlowStatus::Paused,
            FlowStatus::Paused => FlowStatus::Draft,
        };
        $flow->save();

        unset($this->flows);
    }

    public function deleteFlow(int $flowId): void
    {
        Flow::where('workspace_id', app('currentWorkspace')->id)->where('id', $flowId)->delete();
        unset($this->flows);
    }

    public function render()
    {
        return view('livewire.app.flows')
            ->layout('layouts.app', ['title' => 'Flows']);
    }
}
